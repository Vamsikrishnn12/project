import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Rocket, ChevronDown, Sparkles } from 'lucide-react';

function App() {
  return (
   
    <div className="min-h-screen bg-[#f1f0ee] overflow-x-hidden">
      {/* Top Banner */}
      <div className="w-full bg-[#161616] border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-2 flex justify-center items-center bg-[#161616] text-[#f1f0ee]">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-4 w-4 text-[#6366F1]" />
            <span className="text-sm text-[#f1f0ee]-600 ">Export your site to React</span>
            <motion.span
              whileHover={{ scale: 1.02 }}
              className="text-sm text-[#f1f0ee] font-medium cursor-pointer flex items-center"
            >
              Try it now <ArrowRight className="ml-1 h-4 w-4 text-[#f1f0ee]-600" />
            </motion.span>
          </div>
        </div>
      </div>

      {/* <div className="transparent p-6 bg-opacity-50 border border-gray-300 rounded-lg">
         <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=500&fit=crop"></img> */}
      <nav className="sticky top-0 w-full bg-[#f1f0ee] backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            
            <div className="flex items-center cursor-pointer">
              <Rocket className="h-8 w-8 text-[#6366F1]" />
              <span className="ml-2 text-xl font-bold text-gray-900">Relume</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <div className="relative group">
                <button className="flex items-center space-x-1 text-gray-700 hover:text-gray-900 font-bold">
                  <span>Products</span>
                  <ChevronDown className="h-4 w-4 transition-transform group-hover:rotate-180 font-bold" />
                </button>
              </div>
              <a href="#" className="text-gray-1000 hover:text-gray-900 font-bold">Community</a>
              <a href="#" className="text-gray-700 hover:text-gray-900 font-bold">Pricing</a>
              <a href="#" className="text-gray-700 hover:text-gray-900 font-bold">Learn</a>
              <a href="#" className="text-gray-700 hover:text-gray-900 font-bold">Contact Sales</a>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-[#161616]-1000 font-bold hover:text-[#161616]">Log in</button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-[#161616] text-white px-4 py-2 rounded-lg hover:bg-[#4F46E5] transition-colors"
              >
                Start for free
              </motion.button>
            </div>
          </div>
        </div>
      </nav>
   
      
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none absolute">
        <div className="absolute -top-40 -right-40 w-[600px] h-[600px] purple-gradient rounded-full opacity-50"></div>
        <div className="absolute top-1/3 -left-40 w-[600px] h-[600px] purple-gradient rounded-full opacity-50"></div>
      </div>

    
      <div className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8 z-10">
        <div className="max-w-7xl mx-auto">
        
          <div className="text-center mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="bg-[#f1f0ee] inline-flex items-center space-x-1 px-3 py-2 rounded-full shadow-sm border border-[#161616]"
            >
              <span className="text-xl font-semibold text-[#fc7973]">400k+</span>
              <span className="text-[#161616] font-bold">Designers & Devs build with Relume</span>
              <div className="flex -space-x-2">
                <img className="h-8 w-8 rounded-full border-2 border-white" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop" alt="User" />
                <img className="h-8 w-8 rounded-full border-2 border-white" src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop" alt="User" />
                <img className="h-8 w-8 rounded-full border-2 border-white" src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=64&h=64&fit=crop" alt="User" />
              </div>
            </motion.div>
          </div>

        
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-7xl md:text-8xl font-bold text-center leading-tight mb-8 text-gray-900"
          >
            Websites designed &<br />
            built faster with AI
          </motion.h1>

        
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl text-gray-600 text-center max-w-3xl mx-auto mb-12"
          >
            Use AI as your design ally, not as a replacement. Effortlessly generate
            sitemaps and wireframes for marketing websites in minutes.
          </motion.p>
        

        
        <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.6 }}
      className="max-w-3xl mx-auto bg-[#f1f0ee] border border-[#d74875] p-6 rounded-2xl shadow-lg"
    >
      <motion.input
        whileHover={{ scaleY: 1.2 }} // Fixed: scaleY instead of scaley
        type="text"
        placeholder="Describe a company in a sentence or two..."
        className="w-full p-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#6366F1] focus:border-transparent transition-all text-lg bg-[#f1f0ee] text-black-900"
      />
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="bg-[#6366F1] text-white px-6 py-3 rounded-xl hover:bg-[#4F46E5] transition-colors flex items-center space-x-2 mt-4"
      >
        <span>Generate</span>
        <ArrowRight className="h-4 w-4" />
      </motion.button>
    </motion.div>
 
          {/* Floating Images */}
         
        </div>
      </div>
    </div>
  );
}

export default App;